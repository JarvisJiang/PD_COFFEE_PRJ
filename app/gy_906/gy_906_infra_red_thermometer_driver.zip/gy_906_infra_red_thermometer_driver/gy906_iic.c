#include "gy906.h"
#include "misc.h"



//��ʱnus
//nusΪҪ��ʱ��us��.		    								   
static void delay_us(u32 nus)
{		
		int i;
		int j = 20;
		for(i = 0 ;  i < nus ; i++)
		{
		do
		{
			__asm("NOP");
		}while(j--);
		j = 20; // 72 MHZ
		}
							    
}

void smbus_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//gy906_delay_init();
	
	//RCC->APB2ENR|=1<<4;//?����1?����a����IO PORTC����?�� 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE );	
	   
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//?a??��?3?
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
 
	SMBus_SCL=1;
	SMBus_SDA=1;
}

void SMBus_Start(void)
{
	
	SDA_OUT();
	SMBus_SDA=1;
	delay_us(1);
	SMBus_SCL=1;
	delay_us(5);
	SMBus_SDA=0;
	delay_us(5);
	SMBus_SCL=0;
	delay_us(2);

}

void SMBus_Stop(void)
{
	SDA_OUT();
	SMBus_SDA=0;
	SMBus_SCL=0;
	delay_us(1);
	SMBus_SCL=1;
	delay_us(5);
//	SMBus_SCL=1;
	SMBus_SDA=1;
	delay_us(10);
	SMBus_SCL=0;
	delay_us(2);
	

}


//??��D��|��e?����?1��?��|��e?����?0
u8 Wait_Ack(void)
{
	u8 times=0;
	SDA_IN();
	SMBus_SCL=0;delay_us(1);
	SMBus_SDA=1;delay_us(1);
//	delay_us(2);
	SMBus_SCL=1;
	delay_us(2);
	while(READ_SDA)
	{
		times++;
		if(times>20)
		{
			SMBus_Stop();
			return 1;
		}
	}
	delay_us(1);
	SMBus_SCL=0;
	return 0;
}

void Ack(void)
{
	SDA_OUT();
	SMBus_SCL=0;
	SMBus_SDA=0;
	delay_us(2);
	SMBus_SCL=1;
	delay_us(5);
	SMBus_SCL=0;
	delay_us(1);
}

void NAck(void)
{
	SDA_OUT();
	SMBus_SCL=0;
	SMBus_SDA=1;
	delay_us(5);
	SMBus_SCL=1;
	delay_us(5);
	SMBus_SCL=0;
	delay_us(1);
}

void SMBus_Send(u8 dat)
{
	u8 i;
	SDA_OUT();
	SMBus_SCL=0;
	for(i=0;i<8;i++)
	{
		SMBus_SDA=(dat&0x80)>>7;
		dat<<=1;
		delay_us(5);
		SMBus_SCL=1;
		delay_us(5);
		SMBus_SCL=0;
		delay_us(5);
	}
}

u8 SMBus_Read(u8 ack)
{
	u8 receive=0;
	u8 k;
	SDA_IN();
	for(k=0;k<8;k++)
	{
		SMBus_SCL=0;
		delay_us(5);
		receive<<=1;
		SMBus_SCL=1;
		delay_us(2);
		if(READ_SDA)
			receive++;
		delay_us(5);
		SMBus_SCL=0;
//		delay_us(2);
	}
	if(!ack)
		NAck();//��?0 2?��|��e
	else
		Ack();//��?1 ��|��e
	return receive;
}
