#include "water_heater.h"
#include "ads1220.h"

const unsigned char  keep_warm[101] = {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,// 0 ~10 ?
											 8, 9 , 20, 32, 33, 34, 35, 36, 37, 38, // 11~20 ?
											39, 40, 41, 42, 43, 45, 46, 48, 50, 55, // 31~30 ?
											59, 60, 61, 62, 63, 64, 65, 66, 67, 70, // 31~40 ?
											70, 70, 70, 70, 70, 70, 71, 72, 74, 80, // 41~50 ?
											77, 78, 78, 79, 80, 81, 81, 82, 82, 83, // 51~60 ?
											83, 84, 85, 86, 87, 88, 89, 90, 91, 92, // 61~70 ?
											90, 90, 92, 94, 96, 98,100,101,104,108, // 71~80 ?
										 108,109,110,111,112,112,113,114,118,120, // 81~90 ?
										 101,102,103,104,105,106,107,108,109,110, // 91~100 ?
							};


/*************PID**********************************/


struct HEATER_PID {
unsigned int Proportion; // ???? Proportional Const
unsigned int Integral; // ???? Integral Const
unsigned int Derivative; // ???? Derivative Const
unsigned int LastError; // Error[-1]
unsigned int PrevError; // Error[-2]
};
struct HEATER_PID  spid; // PID Control Structure

unsigned int rd_cur_temp;
unsigned int last_temp,set_temper,temp_offset;


/*
��ȡ �����¶� �Ŵ�10��

the read temperature  will  enlarge  10 times
*/
unsigned short ReadTemperature(void)
{
	float rtn;
	short ads1200Data;
	ads1200Data = ADS1220ReadData();
	ads1200Data = ads1200Data>>8;
	
	rtn = DS1220ResConvertToTem(ads1200Data);//
	
	rtn = rtn*10;
	
	return (unsigned short)rtn;
	
}

/************************************************
              PID??
*************************************************/ 
void PIDInit (struct HEATER_PID  *pp) 
{ 
	int i;
	char *aa;
	aa = (char *)pp;
	
	for(i = 0; i < sizeof(struct HEATER_PID); i++ )
	{
		aa[i] = 0;
	}

} 
/************************************************
              ????PID??? 
51????????????,???int???
*************************************************/
unsigned int PIDCalc( struct HEATER_PID *pp, unsigned int NextPoint ) 
{ 
  unsigned int dError,Error,pError; 
  //???????:
  //Pdt=Kp*[E(t)-E(t-1)]+Ki*E(t)+Kd*[E(t)-2*E(t-1)+E(t-2)]
  Error = set_temper - NextPoint;       // ??E(t) 
  pError=Error-pp->LastError;	 //E(t)-E(t-1)
  dError=Error-2*pp->LastError+pp->PrevError; //E(t)-2*E(t-1)+E(t-2) 
  pp->PrevError = pp->LastError; 
  pp->LastError = Error; 
  return ( 
            pp->Proportion * pError        //?? 
            + pp->Integral *Error  //??? 
            + pp->Derivative * dError	  // ???
			);  
} 

/************************************************
				PID?????
*************************************************/
void PIDBEGIN() 
{ 
  PIDInit(&spid); // Initialize Structure 
  spid.Proportion = 10; // Set PID Coefficients 10
  spid.Integral = 5; 	//5
  spid.Derivative = 2; 	// 4
}
#if 1
/*********************************************************** 
             PID
***********************************************************/ 
void compare_temper() 		//PID????????
{ 
  unsigned char i; 
	unsigned int temp;
	static unsigned int last_set_temper;
	static unsigned int rout; // PID Response (Output) 
	static unsigned int rin; // PID Feedback (Input)
	float set_value;
	unsigned char PWM,last_PWM;
  if(set_temper > rd_cur_temp) 
   { 
    if(set_temper-rd_cur_temp > 80)//different  larger than 8 �棬 all speed up 
     { 
		 config_heat_up_pwm(100);// all speed up  heater
	   PWM = 250 ; 
	   temp = ReadTemperature(); 
     }
	else 	//pid?????
    {
	  for(i=0;i<20;i++) //8????PID????,10??? ?PID????T=10
	     { 
	      temp = ReadTemperature();//PID?????????
				rin = temp ;
	      rout = PIDCalc ( &spid,rin ); // PID????
				 /*
				 add later
				 */
		  //DelayMs(5); //delay
	     }//PID??????(0-255)??pwm???? 
		 PWM = rout ;//+ stay_warm[(unsigned char)set_temper/10];	
		if( set_temper- temp < 8) {
			PWM = rout + temp_offset- 40 + keep_warm[set_temper/10];//keep_warm[(unsigned char)set_temper/10];
		  set_value = (float)PWM/2.55;
			config_heat_up_pwm((unsigned short)set_value);
    } 
   } 
 }
  else if(set_temper <= rd_cur_temp)      //??????????pwm??????????,?????
   { 

     if(rd_cur_temp - set_temper < 3){	 //?????????? ?5???
			PWM = set_temper/10 + temp_offset- 60 +10*(3-rd_cur_temp+set_temper) ;
			set_value = (float)PWM/2.55;
			config_heat_up_pwm((unsigned short)set_value);
			temp = ReadTemperature();
	 
	 	 }
	 else{	    // ?????????? ?5???
			config_heat_up_pwm(1);
			temp = ReadTemperature();
			PWM = 0 ;
	 }
   }
		if((last_temp != temp)|(last_PWM != PWM)|(last_set_temper != set_temper))
		{
			last_temp = temp ;
			last_PWM  = PWM	 ;
		} 
		else
		{
			last_temp = temp ;
			last_PWM  = PWM ;
		}

	/*if((set_temper-temper > 6)&&(set_temper-temper>= 0)){ //????????????
		 if(temp < last_temp){
		  	spid.Integral += 2;
			}
	 } */
	if(set_temper > last_set_temper){
	    last_set_temper = set_temper ;	 
		if(set_temper-last_set_temper >= 100) { //?????????
		 spid.Integral = 4;
			} 
		else{
		  spid.Integral= 5;
		}
	}
	else{
	last_set_temper = set_temper ;
	}

	if(set_temper-rd_cur_temp > 0){
		if( set_temper-rd_cur_temp < 10 ){	//????????
			if(set_temper-rd_cur_temp > 2){

			 spid.Integral = (set_temper-rd_cur_temp)/2+1 ; }
			else{

			 spid.Integral = 1 ;
			}

			if(temp < last_temp){
		  	spid.Integral += 1;
			}
		}
		else{
		   if(temp < last_temp){
		  	spid.Proportion += 3;
			if(temp < last_temp){
		  	spid.Integral += 2;
			}
			}
			else{
			 spid.Proportion = 9 ;
			}
		}

	}	 
}
#endif

void start_water_heater(void)
{
	
}

void test_water_heater(void)
{
	
}





